def sumints(n):
   """Return the sum of the first n integers"""
   sum = 0
   for idx in range(1,n+1):
      sum = sum + idx
   return sum
